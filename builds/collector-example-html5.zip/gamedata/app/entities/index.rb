require "app/entities/player.rb"
require "app/entities/opponent.rb"
require "app/entities/coin.rb"
