class Title < Draco::Entity
  component Label, text: "Teeny Tiny Space Game", color: [255, 255, 255], size_enum: 4, alignment_enum: 1
  component Position, x: 640, y: 360
end
