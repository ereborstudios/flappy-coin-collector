class Sprite < Draco::Component
  attribute :w
  attribute :h
  attribute :path
end
