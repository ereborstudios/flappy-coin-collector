class Attacking < Draco::Component
  attribute :cooldown, default: 20
  attribute :laser_spawned, default: false
end
