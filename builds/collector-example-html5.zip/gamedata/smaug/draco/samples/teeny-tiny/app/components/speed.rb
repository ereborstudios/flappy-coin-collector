class Speed < Draco::Component
  attribute :speed, default: 1
end
