class PlayerControlled < Draco::Component
end
