class EnemyAI < Draco::Component
end
