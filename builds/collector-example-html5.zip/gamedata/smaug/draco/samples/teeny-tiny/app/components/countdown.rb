class Countdown < Draco::Component
  attribute :remaining, default: 0
end
