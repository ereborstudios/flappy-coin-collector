class GameStory < Draco::Entity
  component Label, text: "Destroy the enemies before they destroy your planet!", color: [255, 255, 255], alignment_enum: 1
  component Position, x: 640, y: 315
end
