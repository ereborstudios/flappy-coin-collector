class RestartInstructions < Draco::Entity
  component Position, x: 640, y: 320
  component Label, text: 'Press "r" to restart', color: [255, 255, 255], alignment_enum: 1
end
