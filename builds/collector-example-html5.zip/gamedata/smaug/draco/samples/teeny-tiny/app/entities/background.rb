class Background < Draco::Entity
  component Position, x: 0, y: 0
  component Sprite, w: 1280, h: 720, path: "sprites/background.png"
end
