class HealthBar < Draco::Component
end
