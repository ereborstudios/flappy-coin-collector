class Destroyable < Draco::Component
end
