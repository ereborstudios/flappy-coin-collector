# Teeny Tiny Space Game

[itch.io page](https://guitsaru.itch.io/teeny-tiny-space-game).

Teeny Tiny Space Game is a 20 second space shooter created for the [TeenyTiny DragonRuby MiniGameJam](https://itch.io/jam/teenytiny-dragonruby-minigamejam-2020).

## Acknowledgements

All assets downloaded from [Kenney](https://kenney.nl).
