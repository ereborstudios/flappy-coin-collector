class Collides < Draco::Component
end
