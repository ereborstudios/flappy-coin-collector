class Sprite < Draco::Component
  attribute :path
  attribute :angle, default: 0
end
