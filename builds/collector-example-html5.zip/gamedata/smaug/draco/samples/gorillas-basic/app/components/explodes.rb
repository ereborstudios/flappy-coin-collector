class Explodes < Draco::Component
end
