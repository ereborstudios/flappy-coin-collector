class Owned < Draco::Component
  attribute :owner
end
