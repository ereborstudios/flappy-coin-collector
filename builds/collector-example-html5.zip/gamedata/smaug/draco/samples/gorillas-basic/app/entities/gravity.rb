class Gravity < Draco::Entity
  component Speed, speed: 0.25
end
