class Lines < Draco::Component
  attribute :lines, default: []
end
