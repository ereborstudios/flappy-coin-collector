class Killable < Draco::Component
end
