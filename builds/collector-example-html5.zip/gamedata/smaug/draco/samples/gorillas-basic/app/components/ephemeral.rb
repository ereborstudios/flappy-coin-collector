class Ephemeral < Draco::Component
end
