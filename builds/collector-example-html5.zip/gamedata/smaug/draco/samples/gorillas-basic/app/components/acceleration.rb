class Acceleration < Draco::Component
  attribute :x, default: 0
  attribute :y, default: 0
end
