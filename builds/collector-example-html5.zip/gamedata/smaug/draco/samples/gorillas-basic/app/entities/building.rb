class Building < Draco::Entity
  component Ephemeral
  component Explodes
  component Position
  component Size
  component Solid
  component Solids
  component StaticRendered
end
