$gtk.reset 100
$gtk.supress_framerate_warning = true
$gtk.require 'app/tests/building_generation_tests.rb'
$gtk.tests.start
