class Solids < Draco::Component
  attribute :solids, default: []
end
