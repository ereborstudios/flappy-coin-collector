class Background < Draco::Entity
  component BackgroundColor
end
