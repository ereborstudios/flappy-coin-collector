class StaticRendered < Draco::Component
  attribute :rendered, default: false
end
