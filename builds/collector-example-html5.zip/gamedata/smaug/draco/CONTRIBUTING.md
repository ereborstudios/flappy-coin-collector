# Contributing

## Legal

By submitting a Pull Request, you disavow any rights or claims to any changes submitted to the Draco project and assign the copyright of those changes to Big Refactor LLC.

If you cannot or do not want to reassign those rights (your employment contract for your employer may not allow this), you should not submit a PR. Open an issue and someone else can do the work.
