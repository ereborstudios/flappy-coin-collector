require "app/entities/common/camera.rb"
