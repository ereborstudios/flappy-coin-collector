require "app/worlds/common/world.rb"
