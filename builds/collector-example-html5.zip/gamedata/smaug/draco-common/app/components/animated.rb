class Animated < Draco::Component
  attribute :current_frame, default: 0
  attribute :frames, default: {}
end
