class Sprite < Draco::Component
  attribute :path
  attribute :flip_vertically, default: false
  attribute :flip_horizontally, default: false
end
