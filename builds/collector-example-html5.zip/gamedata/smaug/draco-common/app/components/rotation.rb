class Rotation < Draco::Component
  attribute :angle, default: 0
end
