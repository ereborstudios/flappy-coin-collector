class Visible < Draco::Component
end
