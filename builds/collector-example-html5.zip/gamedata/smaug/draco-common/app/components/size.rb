class Size < Draco::Component
  attribute :width, default: 0
  attribute :height, default: 0
end
