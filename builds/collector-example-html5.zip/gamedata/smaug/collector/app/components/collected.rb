class Collected < Draco::Component
end
