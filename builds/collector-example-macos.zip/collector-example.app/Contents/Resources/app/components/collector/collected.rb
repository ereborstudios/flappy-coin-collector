class Collected < Draco::Component
  attribute :collector_id
end
