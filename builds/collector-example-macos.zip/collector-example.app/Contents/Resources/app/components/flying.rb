class Flying < Draco::Component
  attribute :direction
end
