require "app/worlds/collector_example.rb"
