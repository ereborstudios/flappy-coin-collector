require "app/systems/common/animate.rb"
require "app/systems/common/render_sprites.rb"
