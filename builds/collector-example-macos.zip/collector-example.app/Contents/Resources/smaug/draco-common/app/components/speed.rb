class Speed < Draco::Component
  attribute :speed, default: 1
  attribute :acceleration, default: 1.25
  attribute :deceleration, default: 0.75
end
