# frozen_string_literal: true

RSpec.describe Draco do
  it "has a version number" do
    expect(Draco::VERSION).not_to be nil
  end
end
