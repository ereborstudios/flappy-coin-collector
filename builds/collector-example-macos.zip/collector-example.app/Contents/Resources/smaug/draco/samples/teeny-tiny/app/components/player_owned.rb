class PlayerOwned < Draco::Component
end
