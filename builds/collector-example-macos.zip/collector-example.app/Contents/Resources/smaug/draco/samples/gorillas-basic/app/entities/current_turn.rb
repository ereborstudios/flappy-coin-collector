class CurrentTurn < Draco::Entity
  component Turn
end
