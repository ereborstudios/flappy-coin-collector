class StartGameInstructions < Draco::Entity
  component Label, text: "Press any key to start", color: [255, 255, 255], alignment_enum: 1, size_enum: -2
  component Position, x: 640, y: 150
end
