class Empty < Draco::Component
end
