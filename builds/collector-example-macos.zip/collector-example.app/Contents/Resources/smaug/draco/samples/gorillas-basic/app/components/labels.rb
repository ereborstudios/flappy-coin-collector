class Labels < Draco::Component
  attribute :labels, default: []
end
