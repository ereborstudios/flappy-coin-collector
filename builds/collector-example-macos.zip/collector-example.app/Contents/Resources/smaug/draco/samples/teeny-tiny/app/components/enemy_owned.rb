class EnemyOwned < Draco::Component
end
