class Score < Draco::Component
  attribute :score, default: 0
end
