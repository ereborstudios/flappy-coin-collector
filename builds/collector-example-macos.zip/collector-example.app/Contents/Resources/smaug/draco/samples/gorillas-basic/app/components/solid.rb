class Solid < Draco::Component
end
