class Rotation < Draco::Component
  attribute :velocity, default: 20
end
