class Laser < Draco::Component
end
