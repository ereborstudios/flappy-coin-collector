class Rendered < Draco::Component
end
