class BackgroundColor < Draco::Component
  attribute :color, default: [33, 32, 87]
end
