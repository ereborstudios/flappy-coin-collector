class Destroyed < Draco::Component
end
