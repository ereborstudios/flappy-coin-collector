require "app/components/collector/collected.rb"
require "app/components/collector/collectible.rb"
require "app/components/collector/collector.rb"
