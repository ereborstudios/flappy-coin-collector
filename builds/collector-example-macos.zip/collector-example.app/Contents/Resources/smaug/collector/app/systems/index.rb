require "app/systems/collector/collect.rb"
