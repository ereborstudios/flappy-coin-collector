class Collectible < Draco::Component
end
