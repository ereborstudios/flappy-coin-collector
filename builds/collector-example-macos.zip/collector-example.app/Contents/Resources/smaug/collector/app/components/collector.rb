class Collector < Draco::Component
end
